#version 430 compatibility

#define STAGE_VERTEX

#define BLOOM_DOWNSAMPLE_PASS
#define BLOOM_DOWNSAMPLE_PASS_INDEX 4

#include "/programs/post/bloom/tile_write.glsl"
