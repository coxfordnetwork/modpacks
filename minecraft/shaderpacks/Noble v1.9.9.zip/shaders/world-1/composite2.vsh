#version 430 compatibility

#define STAGE_VERTEX
#define WORLD_NETHER

#include "/programs/composite/specular_fog_front.glsl"
