#version 430 compatibility

#define STAGE_FRAGMENT

#include "/programs/post/depth_of_field_write.glsl"
