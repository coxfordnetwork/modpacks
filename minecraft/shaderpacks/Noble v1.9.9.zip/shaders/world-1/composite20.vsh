#version 430 compatibility

#define STAGE_VERTEX

#define BLOOM_UPSAMPLE_PASS
#define BLOOM_UPSAMPLE_PASS_INDEX 3

#include "/programs/post/bloom/tile_write.glsl"
