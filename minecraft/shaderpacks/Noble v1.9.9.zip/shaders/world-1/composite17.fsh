#version 430 compatibility

#define STAGE_FRAGMENT

#define BLOOM_UPSAMPLE_PASS
#define BLOOM_UPSAMPLE_PASS_INDEX 6

#include "/programs/post/bloom/tile_write.glsl"
