#version 430 compatibility

#define STAGE_VERTEX
#define WORLD_NETHER

#include "/programs/deferred/shadows_skylight_write.glsl"
