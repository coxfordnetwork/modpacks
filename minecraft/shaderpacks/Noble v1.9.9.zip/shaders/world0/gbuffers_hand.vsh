#version 430 compatibility

#define PROGRAM_HAND
#define STAGE_VERTEX
#define WORLD_OVERWORLD

#include "/programs/gbuffers/opaque.glsl"
