#version 430 compatibility

#define PROGRAM_BEACONBEAM
#define STAGE_FRAGMENT
#define WORLD_OVERWORLD

#include "/programs/gbuffers/opaque.glsl"
