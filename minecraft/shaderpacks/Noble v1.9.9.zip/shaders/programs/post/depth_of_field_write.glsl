/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

#include "/settings.glsl"
#include "/include/taau_scale.glsl"

#if DOF == 0

    #include "/programs/discard.glsl"
    
#else

    #if defined STAGE_VERTEX

        #include "/programs/vertex_taau.glsl"

    #elif defined STAGE_FRAGMENT

        /* RENDERTARGETS: 0 */

        layout (location = 0) out vec3 colorOut;

        in vec2 textureCoords;
        in vec2 vertexCoords;

        #include "/include/common.glsl"

        #include "/include/utility/sampling.glsl"

        #include "/include/post/depth_of_field.glsl"

        #include "/include/post/exposure.glsl"

        void main() {

            // Depth of field setup

            float depth = texture(depthBuffer0, vertexCoords).r;

            if (depth < handDepth) {
                colorOut = texture(MAIN_BUFFER, vertexCoords).rgb;
                return;
            }

            //depth = textureBicubic(DEPTH_MIPMAP_BUFFER, getDepthMip(textureCoords, 4)).r;

            depth = screenToViewDepth(depth, projectionInverseMatrix);

            // Target depth computation

            #if DOF_DEPTH == 0

                vec2  centerCoords = vec2(RENDER_SCALE * 0.5);
                float centerDepth  = texture(depthBuffer0, centerCoords).r;

                float targetDepth  = screenToViewDepth(centerDepth, projectionInverseMatrix);

            #else

                float targetDepth = float(DOF_DEPTH);
                
            #endif

            float exposure = CURRENT_EXPOSURE();

            // Depth of field computation

            depthOfField(colorOut, MAIN_BUFFER, vertexCoords, getCoC(depth, targetDepth), exposure);

            // Apply exposure to output to preserve HDR scale

            colorOut *= exposure;
        }
        
    #endif

#endif
