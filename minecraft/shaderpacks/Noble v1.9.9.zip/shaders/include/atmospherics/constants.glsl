/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

/*
    [References]:
        Serdyuchenko et al. (2014). High spectral resolution ozone absorption cross-sections – Part 1: Measurements, data analysis and comparison with previous measurements around 293 K. https://amt.copernicus.org/articles/7/609/2014/amt-7-609-2014.pdf
        Tatum & Fairbairn. (2026). Planetary Photometry. https://www.booksofall.com/planetary-photometry-tatum-and-fairbairn/
*/

/* ATMOSPHERIC CONSTANTS */

const float atmosphereLowerOffset = -5e3;

const float planetRadius          = 6371e3;                               // Meters (m)
const float atmosphereLowerRadius = planetRadius + atmosphereLowerOffset; // Meters (m)
const float atmosphereUpperRadius = planetRadius + 110e3;                 // Meters (m)

const vec2 scaleHeights    = vec2(8.40e3, 1.25e3); // Meters (m)
const vec2 invScaleHeights = 1.0 / scaleHeights;

const float mieScatteringAlbedo = 0.9;
const float mieAnisotropyFactor = 2346.25355; // energy term e (unitless)

const float ozonePeakDensity    = 5e-6; // Parts per million (ppm)
const float ozonePeakAltitude   = 35e3; // Meters (m)
const float ozoneUnitConversion = 1e-4; // Converts from cm² to m²

const float airNumberDensity    = 2.5035422e25;
const float ozoneNumberDensity  = airNumberDensity * exp(-ozonePeakAltitude / 8e3) * ozonePeakDensity;

// Coefficients in cm²/molecule

const vec3 rayleighScatteringCoefficientsSunny = vec3(6.42905682e-6, 1.08663713e-5, 2.4844733e-5);
const vec3 mieScatteringCoefficientsSunny      = vec3(4e-6);

const vec3 rayleighScatteringCoefficientsRain = vec3(6.42e-5, 6.98e-5, 8.9e-5);
const vec3 mieScatteringCoefficientsRain      = vec3(1e-5);

vec3 rayleighScatteringCoefficients = mix(rayleighScatteringCoefficientsSunny, rayleighScatteringCoefficientsRain, wetness * biome_may_rain);
vec3 mieScatteringCoefficients      = mix(mieScatteringCoefficientsSunny     , mieScatteringCoefficientsRain     , wetness * biome_may_rain);

const vec3 ozoneExtinctionCoefficients = vec3(4.51103e-21, 3.28547e-21, 5.36774e-22) * ozoneNumberDensity * ozoneUnitConversion;

const vec3 rayleighScatteringCoefficientsEnd = vec3(2e-5, 4e-6, 3e-5);
const vec3 mieScatteringCoefficientsEnd      = vec3(1e-5);
const vec3 rayleighExtinctionCoefficientsEnd = rayleighScatteringCoefficientsEnd;
const vec3 mieExtinctionCoefficientsEnd      = mieScatteringCoefficientsEnd / mieScatteringAlbedo;

mat2x3 atmosphereScatteringCoefficients = mat2x3(
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(rayleighScatteringCoefficients),
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(mieScatteringCoefficients)
);

mat3x3 atmosphereAttenuationCoefficients = mat3x3(
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(rayleighScatteringCoefficients),
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(mieScatteringCoefficients / mieScatteringAlbedo),
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(ozoneExtinctionCoefficients)
);

const mat2x3 atmosphereScatteringCoefficientsEnd = mat2x3(
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(rayleighScatteringCoefficientsEnd),
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(mieScatteringCoefficientsEnd)
);

const mat3x3 atmosphereAttenuationCoefficientsEnd = mat3x3(
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(rayleighExtinctionCoefficientsEnd),
    SRGB_TO_WORKING_SPACE_COEFFICIENTS(mieExtinctionCoefficientsEnd),
    vec3(0.0)
);

vec3 atmosphereRayPosition = vec3(0.0, planetRadius, 0.0) + cameraPosition;

/* CLOUDS CONSTANTS */

const float cloudsFallbackDistance = 65534.0;

#if defined WORLD_OVERWORLD

    const float cloudsExtinctionCoefficient = 0.06;
    const float cloudsScatteringCoefficient = 0.99;

#else

    const float cloudsExtinctionCoefficient = 0.20;
    const float cloudsScatteringCoefficient = 0.99;

#endif

const float cloudsTransmitThreshold = 0.05;

const float cloudsForwardsLobe = 0.80;
const float cloudsBackardsLobe = 0.35;
const float cloudsForwardsPeak = 0.85;
const float cloudsBackScatter  = 0.20;
const float cloudsPeakWeight   = 0.10;

const int   cloudsMultiScatterSteps = 8;
const float cloudsExtinctionFalloff = 0.70;
const float cloudsScatteringFalloff = 0.60;
const float cloudsAnisotropyFalloff = 0.80;

/* FOG CONSTANTS */

const float airFogForwardsLobe = 0.75;
const float airFogBackardsLobe = 0.20;
const float airFogForwardsPeak = 0.95;
const float airFogBackScatter  = 0.08;
const float airFogPeakWeight   = 0.35;

/* CELESTIAL CONSTANTS */

// End star

const float azimuthStar  = 25.0;
const float altitudeStar = 45.0;

const float phiStar   = radians(azimuthStar);
const float thetaStar = radians(90.0 - altitudeStar);

const vec3 starVector = normalize(vec3(sin(thetaStar) * cos(phiStar), cos(thetaStar), sin(thetaStar) * sin(phiStar)));

const float starRadius   = 2.171e11;
const float starDistance = 6.07852e12;

// Sun

const float sunRadius   = 6.9634e8;
const float sunDistance = 1.496e11;

// Moon

const float moonRadius   = 1.7374e6;
const float moonDistance = 3.8440e8;
const float moonAlbedo   = 0.12; // The full Moon reflects approximately 11-14% of the Sun's emitted light 

// Angular radii

const float sunAngularRadius  = CELESTIAL_SIZE_MULTIPLIER * sunRadius  / sunDistance;
const float moonAngularRadius = CELESTIAL_SIZE_MULTIPLIER * moonRadius / moonDistance;
const float starAngularRadius = CELESTIAL_SIZE_MULTIPLIER * starRadius / starDistance;

float shadowLightAngularRadius = sunAngle < 0.5 ? sunAngularRadius : moonAngularRadius;

// Photometric constants

uniform int moonPhase;

vec3 getFictiveSunVector() {
    // (Moon phase / 8) * 2 * pi
    const float sweepAngle = float(moonPhase) * 0.125 * TAU;

    vec3 tangent   = abs(moonVector.y) < 0.999 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 bitangent = normalize(cross(tangent, moonVector));

    return normalize(-moonVector * cos(sweepAngle) + bitangent * sin(sweepAngle));
}

vec3 fictiveSunVector = getFictiveSunVector();

// Analytically computes the Lambertian angular term for the Moon's BRDF
// This way, Moon phases affect its radiance
float lambertPhase() {
    float phaseAngle = acos(clamp(dot(-moonVector, fictiveSunVector), -1.0, 1.0));

    return (sin(phaseAngle) + (PI - phaseAngle) * cos(phaseAngle)) * RCP_PI;
}

// Brightness of light reaching the Earth (~126'000 lux)
const vec3 sunIlluminance = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(SUN_COLOR_R, SUN_COLOR_G, SUN_COLOR_B) * 0.01) * 126e3;
const vec3 sunLuminance   = sunIlluminance / coneAngleToSolidAngle(sunAngularRadius / CELESTIAL_SIZE_MULTIPLIER);

vec3 moonLuminance   = moonAlbedo * sunIlluminance * lambertPhase();
// The rough amount of light the moon emits that reaches the Earth
vec3 moonIlluminance = moonLuminance * coneAngleToSolidAngle(moonAngularRadius / CELESTIAL_SIZE_MULTIPLIER);

const vec3 starIlluminance = vec3(0.553, 0.298, 0.71) * END_STAR_BRIGHTNESS;
const vec3 starLuminance   = starIlluminance / coneAngleToSolidAngle(starAngularRadius  / CELESTIAL_SIZE_MULTIPLIER);

// Light vectors

#if defined WORLD_OVERWORLD || defined WORLD_NETHER

    vec3 lightVectorView  = shadowLightVectorView;
    vec3 lightVectorWorld = shadowLightVectorWorld;

#elif defined WORLD_END

    vec3 lightVectorView  = normalize(mat3(gbufferModelView) * starVector);
    vec3 lightVectorWorld = starVector;

#endif
