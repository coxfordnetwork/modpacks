/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

uniform vec3 upPosition;

float starfield(vec3 viewPosition, vec3 lightVector) {

    vec3 sceneDirection = normalize(viewToWorld(viewPosition));

    #if defined WORLD_OVERWORLD

        sceneDirection = rotate(sceneDirection, lightVector, vec3(0.0, 0.0, 1.0));


    #elif defined WORLD_END

        sceneDirection = rotate(sceneDirection, lightVector, TIME * END_STARS_ROTATION_SPEED);

    #endif

    vec3  position = sceneDirection * STARS_SCALE;
    vec3  index    = floor(position);
    float radius   = lengthSqr(position - index - 0.5);

    float VdotU = dot(normalize(viewPosition), upPosition);

    #if defined WORLD_END
        VdotU = abs(VdotU);
    #else
        VdotU = saturate(VdotU);
    #endif

    float angularFactor = max0(sqrt(sqrt(VdotU)));

    float falloff = pow2(quinticStep(0.5, 0.0, radius));

    float rng = hash13(index);

    float star = 1.0;
    
    if (VdotU > 0.0) {
        star *= rng;
        star *= hash13(-index + 0.1);
    }

    star = saturate(star - (1.0 - STARS_AMOUNT * 0.0025));

    float luminosity = STARS_LUMINANCE * luminanceAP1(blackbody(mix(STARS_MIN_TEMP, STARS_MAX_TEMP, rng)));

    return star * angularFactor * falloff * luminosity;
}

vec3 physicalSun(vec3 sceneDirection) {
    return dot(sceneDirection, sunVector) < cos(sunAngularRadius) ? vec3(0.0) : sunLuminance * RCP_PI;
}

vec3 physicalMoon(vec3 sceneDirection) {
    vec2 sphere = intersectSphere(-moonVector, sceneDirection, moonAngularRadius);

    if (sphere.y >= 0.0) {

        vec3 moonNormal = normalize(sceneDirection * sphere.x - moonVector);

        float NdotL = max0(dot(moonNormal, fictiveSunVector));

        return moonAlbedo * NdotL * RCP_PI * sunIlluminance;
    }

    return vec3(0.0);
}

vec3 physicalStar(vec3 sceneDirection) {
    return dot(sceneDirection, starVector) < cos(starAngularRadius) ? vec3(0.0) : starLuminance * RCP_PI;
}

vec3 renderAtmosphere(vec2 coords, vec3 viewPosition, vec3 directIlluminance, vec3 skyIlluminance) {
    vec3 sceneDirection = normalize(viewToWorld(viewPosition));

    vec3 atmosphere = textureBicubic(ATMOSPHERE_BUFFER, saturate(projectSphere(sceneDirection))).rgb;

    vec4 clouds = vec4(0.0, 0.0, 0.0, 1.0);

    #if defined CLOUDS_ENABLED

        vec4 cloudsBuffer = texture(CLOUDS_BUFFER, coords * RCP_RENDER_SCALE);

        // Clouds aerial perspective
        float distanceFalloff = pow2(1.0 - quinticStep(0.0, 1.0, exp(-3e-5 * cloudsBuffer.a)));

        cloudsBuffer.rgb = mix(cloudsBuffer.rgb, vec3(0.0, 0.0, 1.0), distanceFalloff);

        clouds.rgb = cloudsBuffer.r * directIlluminance + cloudsBuffer.g * skyIlluminance;
        clouds.a   = cloudsBuffer.b * (1.0 - CLOUDS_AERIAL_PERSPECTIVE_STRENGTH) + CLOUDS_AERIAL_PERSPECTIVE_STRENGTH;
        
    #endif

    return atmosphere * clouds.a + clouds.rgb;
}

vec3 renderCelestialBodies(vec2 coords, vec3 viewPosition) {
    vec3 sceneDirection = normalize(viewToWorld(viewPosition));

    vec3 celestialBodies = vec3(0.0);

    float cloudsTransmittance = 1.0;

    #if defined WORLD_OVERWORLD

        vec3 viewTransmittance = evaluateAtmosphereTransmittance(atmosphereRayPosition, sceneDirection, atmosphereAttenuationCoefficients);
        
        celestialBodies += (physicalSun(sceneDirection) + physicalMoon(sceneDirection)) * viewTransmittance;
        celestialBodies += starfield(viewPosition, sunVector);

        #if defined CLOUDS_ENABLED

            cloudsTransmittance = texture(CLOUDS_BUFFER, coords * RCP_RENDER_SCALE).b;

        #endif

    #elif defined WORLD_END

        celestialBodies += physicalStar(sceneDirection);
        celestialBodies += starfield(viewPosition, starVector) * 0.3;

    #endif

    return celestialBodies * pow5(cloudsTransmittance);
}
