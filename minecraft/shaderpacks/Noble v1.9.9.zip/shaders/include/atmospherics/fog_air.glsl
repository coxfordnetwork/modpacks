/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

/*
    [References]:
        Kutz et al. (2017). Spectral and Decomposition Tracking for Rendering Heterogeneous Volumes. https://media.disneyanimation.com/uploads/production/publication_asset/158/asset/SpectralAndDecompositionTracking.pdf
*/

uniform ivec2 eyeBrightness;
uniform ivec2 eyeBrightnessSmooth;
uniform float rcp240;

float jitter = interleavedGradientNoise(SCREEN_COORDS);

//////////////////////////////////////////////////////////
/*----------------- AIR FOG PARAMETERS -----------------*/
//////////////////////////////////////////////////////////

#if defined WORLD_OVERWORLD

    // Overworld

    const vec3 mistFogAbsorptionCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(MIST_ABSORPTION_R, MIST_ABSORPTION_G, MIST_ABSORPTION_B) * 0.01);
    const vec3 mistFogScatteringCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(MIST_SCATTERING_R, MIST_SCATTERING_G, MIST_SCATTERING_B) * 0.01);

    const vec3 sandFogAbsorptionCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(SANDSTORMS_ABSORPTION_R, SANDSTORMS_ABSORPTION_G, SANDSTORMS_ABSORPTION_B) * 0.01);
    const vec3 sandFogScatteringCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(SANDSTORMS_SCATTERING_R, SANDSTORMS_SCATTERING_G, SANDSTORMS_SCATTERING_B) * 0.01);

    vec3 airFogAbsorptionCoefficients = mix(mistFogAbsorptionCoefficients, sandFogAbsorptionCoefficients, biome_may_sandstorm);
    vec3 airFogScatteringCoefficients = mix(mistFogScatteringCoefficients, sandFogScatteringCoefficients, biome_may_sandstorm);

    const float fogAltitude  = FOG_ALTITUDE;
    const float fogThickness = FOG_THICKNESS;

    vec2  fogShapeFactors = mix(vec2(1.5, 0.4), vec2(2.0, 0.4), biome_may_sandstorm);
    float densityFactor   = wetness;
    float densityMult     = mix(0.03, 0.1, biome_may_sandstorm);

#elif defined WORLD_NETHER

    // Nether

    const vec3 airFogAbsorptionCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(NETHER_ABSORPTION_R, NETHER_ABSORPTION_G, NETHER_ABSORPTION_B) * 0.01);
    const vec3 airFogScatteringCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(NETHER_SCATTERING_R, NETHER_SCATTERING_G, NETHER_SCATTERING_B) * 0.01);

    const float fogAltitude     = max(0.0, FOG_ALTITUDE - SEA_LEVEL);
    const float fogThickness    = FOG_THICKNESS * 2.0;
    const vec2  fogShapeFactors = vec2(2.0, 0.7);
    const float densityFactor   = 0.2;
    const float densityMult     = 0.05;

#elif defined WORLD_END

    // End

    const vec3 endFogAbsorptionCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(END_ABSORPTION_R, END_ABSORPTION_G, END_ABSORPTION_B) * 0.01);
    const vec3 endFogScatteringCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(END_SCATTERING_R, END_SCATTERING_G, END_SCATTERING_B) * 0.01);

    const vec3 endFogFlashAbsorptionCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(0.16, 0.20, 0.14));
    const vec3 endFogFlashScatteringCoefficients = SRGB_TO_WORKING_SPACE_COEFFICIENTS(vec3(1.00, 1.00, 1.00));

    float airFogTransitionFactor = sin(TIME * 2.0);

    vec3 airFogAbsorptionCoefficients = mix(endFogAbsorptionCoefficients, endFogFlashAbsorptionCoefficients, airFogTransitionFactor);
    vec3 airFogScatteringCoefficients = mix(endFogScatteringCoefficients, endFogFlashScatteringCoefficients, airFogTransitionFactor);

    const float fogAltitude     = max(0.0, FOG_ALTITUDE - 100.0);
    const float fogThickness    = min(200.0, (FOG_THICKNESS + 40.0) * 2.0);
    const vec2  fogShapeFactors = vec2(2.0, 0.7);
    const float densityFactor   = 1.0;
    const float densityMult     = 0.1;

#endif

float fogDensity = saturate(FOG_DENSITY + densityFactor);


float calculateAirFogPhase(float cosTheta) {
    float forwardsLobe  = henyeyGreensteinPhase(cosTheta, airFogForwardsLobe);
    float backwardsLobe = henyeyGreensteinPhase(cosTheta,-airFogBackardsLobe);
    float forwardsPeak  = cornetteShanksPhase  (cosTheta, airFogForwardsPeak);

    return mix(mix(forwardsLobe, backwardsLobe, airFogBackScatter), forwardsPeak, airFogPeakWeight);
}

#if AIR_FOG == 2

    //////////////////////////////////////////////////////////
    /*--------------- AIR FOG APPROXIMATION ----------------*/
    //////////////////////////////////////////////////////////

    void computeAirFogApproximation(
        out vec3 scatteringOut,
        out vec3 transmittanceOut,
        vec3 scenePosition,
        float VdotL,
        vec3 directIlluminance,
        vec3 skyIlluminance,
        float skyLight,
        bool sky
    ) {
        float eyeSkylight = pow2(saturate(eyeBrightnessSmooth.y * rcp240));

        float density = quinticStep(0.0, 1.0, saturate(length(scenePosition) / farPlane));

        float airmassFog = density * 0.5 * farPlane * fogDensity * densityMult;

        vec3 transmittanceFog = exp(-airFogAbsorptionCoefficients * airmassFog);

        vec3 scatteringFog  = directIlluminance * calculateAirFogPhase(VdotL);
             scatteringFog += skyIlluminance    * isotropicPhase * eyeSkylight;
             scatteringFog *= airFogScatteringCoefficients * ((1.0 - transmittanceFog) / airFogAbsorptionCoefficients);

        vec3 scatteringAerial    = vec3(0.0);
        vec3 transmittanceAerial = vec3(1.0);

        #if defined WORLD_OVERWORLD && AERIAL_PERSPECTIVE == 1

            float airmassAerial  = density * farPlane * AERIAL_PERSPECTIVE_DENSITY * AERIAL_PERSPECTIVE_DISTANCE_MULTIPLIER;
                  airmassAerial *= (sky ? 0.1 : 1.0);

            vec3 opticalDepthAerial = atmosphereAttenuationCoefficients * vec3(airmassAerial);

            transmittanceAerial = exp(-opticalDepthAerial);

            vec2 phaseAerial = vec2(rayleighPhase(VdotL), kleinNishinaPhase(VdotL, mieAnisotropyFactor));

            vec3 visibleScatteringAerial = saturate((transmittanceAerial - 1.0) / -opticalDepthAerial);

            scatteringAerial += atmosphereScatteringCoefficients * vec2(phaseAerial    * airmassAerial) * visibleScatteringAerial * directIlluminance;
            scatteringAerial += atmosphereScatteringCoefficients * vec2(isotropicPhase * airmassAerial) * visibleScatteringAerial * skyIlluminance * eyeSkylight;

        #endif
        
        scatteringOut    = scatteringFog    + scatteringAerial;
        transmittanceOut = transmittanceFog * transmittanceAerial;
    }

#elif AIR_FOG == 1

    //////////////////////////////////////////////////////////
    /*----------------- AIR FOG RAYMARCHED -----------------*/
    //////////////////////////////////////////////////////////

    uniform sampler3D depthtex2;

    float getAirFogDensity(vec3 position) {

        float altitude   = (position.y - fogAltitude) / fogThickness;
        float shapeAlter = remap(altitude, 0.0, 0.2, 0.0, 1.0) * remap(altitude, 0.9, 1.0, 1.0, 0.0);

        #if defined WORLD_END

            // Rotating cloud centered at the origin (0,0,0)
        
            float movementSpeed = TIME * 10.0;

            position.y -= 60.0;
            position.xz = -position.xz;
            position    = rotate(position, vec3(0.0, 1.0, 0.0), starVector);
            position    = rotate(position, vec3(0.0, 1.0, 0.0), movementSpeed);
            position.xz = -position.xz;
            position.y -= movementSpeed;

        #endif

        #if defined WORLD_NETHER

            //fogShapeFactors = mix(vec2(2.5, 0.6), fogShapeFactors, sqrt(quinticStep(0.0, 1.0, min(125.0, position.y) / 125.0)));

        #endif
        
        vec4  shapeTex   = texture(depthtex2, position * FOG_SHAPE_SCALE * 1e-4);
        float shapeNoise = remap(shapeTex.r, -(1.0 - (shapeTex.g * 0.625 + shapeTex.b * 0.25 + shapeTex.a * 0.125)), 1.0, 0.0, 1.0);
              shapeNoise = (shapeNoise * shapeAlter - (2.0 * shapeAlter * altitude * 0.5 + 0.5)) * fogShapeFactors.x - fogShapeFactors.y;

        #if defined WORLD_OVERWORLD

            shapeNoise *= smoothstep(0.0, 1.0, exp(-abs(position.y - fogAltitude) * 0.03));

        #elif defined WORLD_NETHER

            //fogDensity *= mix(1.2, 1.0, sqrt(quinticStep(0.0, 1.0, min(125.0, position.y) / 125.0)));

        #elif defined WORLD_END

            // End cloud ring shape

            float innerRadius    = 30.0;
            float outerRingStart = 70.0;
            float outerRingEnd   = 250.0;

            float distanceFromCenter = length(position.xz);

            float fogFalloff = quinticStep(innerRadius, outerRingStart, distanceFromCenter) * 
                               pow2(quinticStep(outerRingEnd, outerRingStart, distanceFromCenter)) * 
                               exp(-rcp(distanceFromCenter));

            shapeNoise *= fogFalloff;

        #endif
        
        return saturate(shapeNoise) * fogDensity * densityMult;
    }

    vec2 intersectFogVolume(vec3 rayDirection) {
        
        float rcpDirectionY = 1.0 / rayDirection.y;

        float volumeStart = (fogAltitude                - eyeAltitude) * rcpDirectionY;
        float volumeEnd   = (fogAltitude + fogThickness - eyeAltitude) * rcpDirectionY;

        if (rayDirection.y < 0.0) {
            float tmp = volumeStart;

            volumeStart = volumeEnd;
            volumeEnd   = tmp;
        }

        if (volumeEnd < 0.0) { return vec2(-1.0); }

        return vec2(max0(volumeStart), volumeEnd);
    }

    vec3 evaluateFogTransmittance(vec3 origin, vec3 lightDirection, int stepCount) {

        float stepSize    = 10.0;
        vec3  increment   = lightDirection * stepSize;
        vec3  rayPosition = origin + increment * randF();

        vec3 accumAirmass = vec3(0.0);

        // Transmittance evaluation
        
        for (int i = 0; i < stepCount; i++, rayPosition += increment) {
            accumAirmass += getAirFogDensity(rayPosition) * stepSize;
        }

        return exp(-airFogAbsorptionCoefficients * accumAirmass);
    }

    void computeVolumetricAirFog(
        inout vec3 scatteringOut,
        inout vec3 transmittanceOut,
        vec3 startPosition,
        vec3 endPosition,
        float VdotL,
        vec3 directIlluminance,
        vec3 skyIlluminance,
        bool sky
    ) {
        #if (defined WORLD_NETHER && NETHER_FOG == 0) || (defined WORLD_END && END_FOG == 0)
            return;
        #endif

        // Ray marching setup

        vec3 rayDirection = endPosition - startPosition;

        float rayLength    = lengthSqr(rayDirection);
        float rcpRayLength = inversesqrt(rayLength);
        
        rayLength    *= rcpRayLength;
        rayDirection *= rcpRayLength;

        if (rayLength < EPS) { return; }

        vec3 shadowStartPosition = worldToShadowClip(startPosition);
        vec3 shadowDirection     = mat3(shadowModelView) * rayDirection * diagonal3(shadowProjection);

        const float minDensity = 1e-4;

        //////////////////////////////////////////////////////////
        /*----------------- GROUND FOG TRACING -----------------*/
        //////////////////////////////////////////////////////////

        vec3 scatteringSunGround = vec3(0.0);
        vec3 scatteringSkyGround = vec3(0.0);

        vec3 transmittanceGround = vec3(1.0);

        // Intersecting the fog volume
        vec2 distsToVolume = intersectFogVolume(rayDirection);

        if (distsToVolume.y > 0.0 && fogDensity > minDensity) {

            // Calculating the distance travelled inside the fog volume per step
            float fogRayLength = sky ? distsToVolume.y : rayLength;
                  fogRayLength = clamp(fogRayLength - distsToVolume.x, 0.0, farPlane);

            float fogStepGrowth = exp(fogRayLength * km_to_m * AIR_FOG_SCATTERING_STEPS_GROWTH);

            int fogStepCount = min(int(floor(float(AIR_FOG_MIN_SCATTERING_STEPS) + fogStepGrowth)), AIR_FOG_MAX_SCATTERING_STEPS);

            float fogStepSize = 1.0 / float(fogStepCount);

            fogRayLength *= fogStepSize;
            
            vec3 fogIncrement = rayDirection * fogRayLength;

            vec3 fogRayPosition  = startPosition + rayDirection * (distsToVolume.x + fogRayLength * jitter);
                 fogRayPosition += cameraPosition;

            vec3 fogShadowIncrement = (worldToShadowClip(endPosition) - shadowStartPosition) * fogStepSize;
            vec3 fogShadowPosition  = shadowStartPosition + shadowDirection * (distsToVolume.x + fogRayLength * jitter);

            // Fog phase
            float phaseFog = calculateAirFogPhase(VdotL);

            for (int i = 0; i < fogStepCount && maxOf(transmittanceGround) > EPS; i++) {

                // Incrementing rays
                fogRayPosition    += fogIncrement;
                fogShadowPosition += fogShadowIncrement;

                // Shadows sampling

                vec3 shadow = vec3(1.0);

                #if defined WORLD_OVERWORLD
                
                    shadow = getShadowColor(shadowClipToShadowScreen(fogShadowPosition));

                    #if CLOUDS_SHADOWS == 1 && CLOUDS_LAYER0_ENABLED == 1
                        shadow *= getCloudsShadows(fogRayPosition - cameraPosition);
                    #endif

                #endif

                // Air fog

                float densityFog = getAirFogDensity(fogRayPosition);

                if (densityFog > minDensity) {

                    float airmassFog      = densityFog * mix(fogRayLength, 0.0, length(startPosition) / farPlane);
                    vec3  opticalDepthFog = airFogAbsorptionCoefficients * airmassFog;

                    vec3 stepTransmittanceFog = exp(-opticalDepthFog);
                    vec3 visibleScatteringFog = transmittanceGround * saturate((stepTransmittanceFog - 1.0) / -opticalDepthFog);

                    #if defined WORLD_END && END_FOG_SHADOW_RAY == 1

                        // Direct transmittance to light source (shadow ray)
                        shadow *= evaluateFogTransmittance(fogRayPosition, lightVectorWorld, 4);

                    #endif

                    scatteringSunGround += airFogScatteringCoefficients * airmassFog * phaseFog       * visibleScatteringFog * shadow;
                    scatteringSkyGround += airFogScatteringCoefficients * airmassFog * isotropicPhase * visibleScatteringFog;

                    transmittanceGround *= stepTransmittanceFog;

                }
            }
        }

        //////////////////////////////////////////////////////////
        /*------------- AERIAL PERSPECTIVE TRACING -------------*/
        //////////////////////////////////////////////////////////

        vec3 scatteringSunAerial = vec3(0.0);
        vec3 scatteringSkyAerial = vec3(0.0);

        vec3 multipleScatteringAerial = vec3(0.0);

        vec3 transmittanceAerial = vec3(1.0);

        #if defined WORLD_OVERWORLD && AERIAL_PERSPECTIVE == 1

            float aerialRayLength = rayLength * AERIAL_PERSPECTIVE_DISTANCE_MULTIPLIER;
            
            float aerialStepGrowth = exp(aerialRayLength * km_to_m * AERIAL_PERSPECTIVE_SCATTERING_STEPS_GROWTH);

            int aerialStepCount = min(int(floor(float(AERIAL_PERSPECTIVE_MIN_SCATTERING_STEPS) + aerialStepGrowth)), AERIAL_PERSPECTIVE_MAX_SCATTERING_STEPS);

            float aerialStepSize = 1.0 / float(aerialStepCount);

            aerialRayLength *= aerialStepSize;

            vec3 aerialIncrement = rayDirection * aerialRayLength;

            vec3 aerialRayPosition  = startPosition + aerialIncrement * jitter;
                 aerialRayPosition += cameraPosition;

            vec3 aerialShadowIncrement = (worldToShadowClip(endPosition) - shadowStartPosition) * aerialStepSize;
            vec3 aerialShadowPosition  = shadowStartPosition + aerialShadowIncrement * jitter;

            // Aerial perspective phase
            vec2 phaseAerial = vec2(rayleighPhase(VdotL), kleinNishinaPhase(VdotL, mieAnisotropyFactor));

            for (int i = 0; i < aerialStepCount && maxOf(transmittanceAerial) > EPS; i++) {

                // Shadows sampling

                vec3 shadow = vec3(1.0);
                
                #if defined WORLD_OVERWORLD
                
                    shadow = getShadowColor(shadowClipToShadowScreen(aerialShadowPosition));

                #endif

                // Aerial perspective

                float centerDistance = planetRadius + max0(aerialRayPosition.y - SEA_LEVEL);

                vec3 airmassAerial      = getAtmosphereDensities(centerDistance) * AERIAL_PERSPECTIVE_DENSITY * aerialRayLength;
                vec3 opticalDepthAerial = atmosphereAttenuationCoefficients * airmassAerial;

                vec3 stepTransmittanceAerial = exp(-opticalDepthAerial);

                vec3 integratedStepTransmittanceAerial = saturate((stepTransmittanceAerial - 1.0) / -opticalDepthAerial);

                vec3 visibleScatteringAerial = transmittanceAerial * integratedStepTransmittanceAerial;

                scatteringSunAerial += atmosphereScatteringCoefficients * vec2(airmassAerial.xy * phaseAerial   ) * visibleScatteringAerial * shadow;
                scatteringSkyAerial += atmosphereScatteringCoefficients * vec2(airmassAerial.xy * isotropicPhase) * visibleScatteringAerial;

                vec3 stepScattering       = atmosphereScatteringCoefficients * airmassAerial.xy;
                vec3 stepScatteringAlbedo = stepScattering / maxEps(opticalDepthAerial);

                vec3 multScatteringFactorAerial = stepScatteringAlbedo * 0.84;
                vec3 multScatteringEnergyAerial = multScatteringFactorAerial / (1.0 - multScatteringFactorAerial);
                     multipleScatteringAerial  += multScatteringEnergyAerial * visibleScatteringAerial * stepScattering;

                transmittanceAerial *= stepTransmittanceAerial;

                // Incrementing rays
                aerialRayPosition    += aerialIncrement;
                aerialShadowPosition += aerialShadowIncrement;
            }

        #endif

        //////////////////////////////////////////////////////////
        /*------------- FOG SCATTERING EVALUATION --------------*/
        //////////////////////////////////////////////////////////

        vec3 scatteringSun, scatteringSky;

        if (distsToVolume.x > 0.0) {

            // Ground fog is closer to the camera than aerial perspective fog

            scatteringSun = scatteringSunAerial + scatteringSunGround * transmittanceAerial;
            scatteringSky = scatteringSkyAerial + scatteringSkyGround * transmittanceAerial;

        } else {

            // Aerial perspective fog is closer to the camera than ground fog

            scatteringSun = scatteringSunGround + scatteringSunAerial * transmittanceGround;
            scatteringSky = scatteringSkyGround + scatteringSkyAerial * transmittanceGround;

        }

        scatteringSky += multipleScatteringAerial * isotropicPhase;

        #if defined WORLD_OVERWORLD
            scatteringSky *= eyeBrightnessSmooth.y * rcp240;
        #endif

        scatteringOut += scatteringSun * directIlluminance
                       + scatteringSky * skyIlluminance;
        
        transmittanceOut = transmittanceGround * transmittanceAerial;
    }

#endif
