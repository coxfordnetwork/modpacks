<p align="center">
    <img src="pack.png" />
    <h1 align="center">Default Dark Mode: Legacy4J</h1>
    <h2 align="center">An Standalone Legacy4J Dark Mode Resource Pack for Minecraft: Java Edition</h2>
</p>

<p align="center">
    <a aria-label="Build" href="https://github.com/aricloverALT/Default-Dark-Mode-Legacy4J/actions">
        <img alt="Build" src="https://img.shields.io/github/actions/workflow/status/aricloverALT/Default-Dark-Mode-Legacy4J/optimize.yml">
    </a>
    <a aria-label="Release" href="https://github.com/aricloverALT/Default-Dark-Mode-Legacy4J/releases/latest">
        <img alt="Release" src="https://img.shields.io/github/v/release/aricloverALT/Default-Dark-Mode-Legacy4J">
    </a>
    <a aria-label="License" href="https://creativecommons.org/licenses/by-nc-sa/4.0/">
        <img alt="License" src="https://img.shields.io/badge/license-CC%20BY--NC--SA%204.0-brightgreen.svg">
    </a>
    <a aria-label="GitHub Downloads" href="https://github.com/arichornloverALT/Default-Dark-Mode-Legacy4J/releases">
        <img alt="GitHub Downloads" src="https://img.shields.io/github/downloads/arichornloverALT/Default-Dark-Mode-Legacy4J/total?logo=github">
    </a>
    <a aria-label="Modrinth Downloads" href="https://modrinth.com/resourcepack/default-dark-mode-legacy4j/versions">
        <img alt="Modrinth Downloads" src="https://img.shields.io/modrinth/dt/m3vMfZFQ?labelColor=2D2D2D&color=2D2D2D&label=downloads&logo=modrinth&logoColor=green&style=flat">
    </a>
    <a aria-label="CurseForge Downloads" href="https://www.curseforge.com/minecraft/texture-packs/default-dark-mode-legacy4j/files">
        <img alt="CurseForge Downloads" src="https://cf.way2muchnoise.eu/full_1077191_downloads.svg">
    </a>
    <a aria-label="Darkomizer Downloads" href="https://darkomizer.com">
        <img alt="Darkomizer Downloads" src="https://img.shields.io/endpoint?url=https://api.darkomizer.com/shields/downloads/darkomizer">
    </a>
</p>

<p align="center">
    Default Dark Mode Legacy4J is an add-on of Default Dark Mode. It adds Dark Mode support for Legacy4J & it's other mods! It is recommended to use this if you want the best Legacy4J Dark Mode experience.
</p>

![Banner](https://i.imgur.com/p9lNs6l.png)

## Download
[<img alt="modrinth" width="177" height="56" src="https://i.imgur.com/vzovT62.png">](https://modrinth.com/resourcepack/default-dark-mode-legacy4j) [<img alt="curseforge" width="195" height="56" src="https://i.imgur.com/yvuoYHq.png">](https://legacy.curseforge.com/minecraft/texture-packs/default-dark-mode-legacy4j)
[<img alt="planet_minecraft" width="56" height="56" src="https://cdn.modrinth.com/data/cached_images/c495fd44d871da79ad235d58b332d58c79489b77.jpeg">](https://www.planetminecraft.com/texture-pack/default-dark-mode-legacy4j-1-19-1-21)

## Mod Support

A list of supported mods can be found on the [wiki](https://github.com/nebuIr/Default-Dark-Mode/wiki/Mod-support).

## Preview (Default Dark Mode: Legacy4J)

![Legacy4J Crafting Screen](https://github.com/user-attachments/assets/35e5160c-c750-4f4c-9d3c-d471eaafff87)

#
<a href="https://billing.apexminecrafthosting.com/aff.php?aff=15169"><img src="https://github.com/user-attachments/assets/8becc6ba-6f85-480e-990e-006040118cb2" width="594" height="100" border="0"></a>