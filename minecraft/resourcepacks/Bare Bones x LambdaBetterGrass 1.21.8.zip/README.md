# Bare Bones x LambdaBetterGrass

Thanks for playing with this resource pack and LambdaBetterGrass!
I really appreciate your support. - LambdAurora

You can find me:
- [on my website](https://lambdaurora.dev),
- [on Discord](https://discord.lambdaurora.dev),
- [on GitHub](https://github.com/LambdAurora),
- [on BlueSky](https://bsky.app/profile/lambdaurora.dev)
