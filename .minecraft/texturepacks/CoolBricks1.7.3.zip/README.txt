Credits to NFC for more contrast Stone Brick texture 
https://newfrontiercraft.net/