Same as faithful 32x except:
-Low fire (Easier to see around you when on fire)
-Ores have a colored border texture (Easy to see ores if on the same level as lava)
-Clear GUI, Hotbar & glass texture (This helps you see mobs or players better)